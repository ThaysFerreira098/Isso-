package com.folha.folha.repository;
import com.folha.folha.model.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;
public interface FunRepository extends JpaRepository<Funcionario, Integer> {

}