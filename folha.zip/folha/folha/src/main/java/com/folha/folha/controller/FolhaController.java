package com.folha.folha.controller;
import com.folha.folha.service.FolhaService;
import com.folha.folha.model.Funcionario;
import com.folha.folha.model.Tabelas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;



@Controller
@RequestMapping("/folha")
public class FolhaController {
    
    @Autowired
    FolhaService fs;

    @GetMapping("/")
    public String cadastros(Model model){
        Funcionario funcionario = new Funcionario();
        model.addAttribute("funcionario", funcionario);
        
        return "paginas/form-funcionario";
    }
    @PostMapping("/salvar")
public String salvar(@ModelAttribute("funcionario") Funcionario funcionario){
         fs.salvar(funcionario);
         return "redirect:/folha/";
}
    
   @GetMapping("/tabelas")
     public String cadastroimposto(Model model){
                 Tabelas tabelas = new Tabelas();
        model.addAttribute("tabelas", tabelas);
        
        return "paginas/form-tabela";
        }
    
@PostMapping("/salvarTab")
    public String salvarTab(@ModelAttribute("tabelas") Tabelas tabelas){
        fs.salvarTab(tabelas); 
        return "redirect:/folha/tabelas";
    }
}


     

//@GetMapping("/edita")
 //public String editatabela(@RequestParam("id") Integer id, Model model){
   // Optional<Cardapio> cardapio=cr.findById(id);
 //if(cardapio.isPresent()) {
 //model.addAttribute("cardapio", cardapio.get());
 //return "paginas/form-cardapio";
 //}
 //return "/cardapio/";
 //}
//}
//coloocar editar na tabela 
