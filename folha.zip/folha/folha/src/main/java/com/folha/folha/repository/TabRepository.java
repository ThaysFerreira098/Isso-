package com.folha.folha.repository;
import com.folha.folha.model.Tabelas;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TabRepository extends JpaRepository<Tabelas, Integer> {
}