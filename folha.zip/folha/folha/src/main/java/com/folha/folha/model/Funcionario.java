package com.folha.folha.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.stereotype.Component;
@Component
@Entity

public class Funcionario {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    private int vt;
    private int depir;
    private int salbase;
   private int dep14;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the vt
     */
    public int getVt() {
        return vt;
    }

    /**
     * @param vt the vt to set
     */
    public void setVt(int vt) {
        this.vt = vt;
    }

    /**
     * @return the depir
     */
    public int getDepir() {
        return depir;
    }

    /**
     * @param depir the depir to set
     */
    public void setDepir(int depir) {
        this.depir = depir;
    }

    /**
     * @return the salbase
     */
    public int getSalbase() {
        return salbase;
    }

    /**
     * @param salbase the salbase to set
     */
    public void setSalbase(int salbase) {
        this.salbase = salbase;
    }

    /**
     * @return the dep14
     */
    public int getDep14() {
        return dep14;
    }

    /**
     * @param dep14 the dep14 to set
     */
    public void setDep14(int dep14) {
        this.dep14 = dep14;
    }

}
