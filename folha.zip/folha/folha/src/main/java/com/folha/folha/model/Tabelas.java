package com.folha.folha.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.stereotype.Component;
@Component
@Entity
public class Tabelas {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    // INSS
    private Double tinss1;
    private Double ainss1;
    private Double tinss2;
    private Double ainss2;
    private Double tinss3;
    private Double ainss3;
    private Double tinss4;
    private Double ainss4;

    // Salário Família
    private Double tsf;
    private Double vsf;

    // IRRF Faixas (Teto)
    private Double tirrf1;
    private Double tirrf2;
    private Double tirrf3;
    private Double tirrf4;
    private Double tirrf5;

    // IRRF Alíquotas
    private Double airrf1;
    private Double airrf2;
    private Double airrf3;
    private Double airrf4;
    private Double airrf5;

    // Deduções
    private Double dirrf2; // Adicionei para bater com o HTML anterior (Dedução faixa 2)
    private Double dirrf3; // Adicionei para bater com o HTML anterior (Dedução faixa 3)
    private Double dirrf4; // Adicionei para bater com o HTML anterior (Dedução faixa 4)
    private Double dirrf5;
    private Double dedpdep;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the tinss1
     */
    public Double getTinss1() {
        return tinss1;
    }

    /**
     * @param tinss1 the tinss1 to set
     */
    public void setTinss1(Double tinss1) {
        this.tinss1 = tinss1;
    }

    /**
     * @return the ainss1
     */
    public Double getAinss1() {
        return ainss1;
    }

    /**
     * @param ainss1 the ainss1 to set
     */
    public void setAinss1(Double ainss1) {
        this.ainss1 = ainss1;
    }

    /**
     * @return the tinss2
     */
    public Double getTinss2() {
        return tinss2;
    }

    /**
     * @param tinss2 the tinss2 to set
     */
    public void setTinss2(Double tinss2) {
        this.tinss2 = tinss2;
    }

    /**
     * @return the ainss2
     */
    public Double getAinss2() {
        return ainss2;
    }

    /**
     * @param ainss2 the ainss2 to set
     */
    public void setAinss2(Double ainss2) {
        this.ainss2 = ainss2;
    }

    /**
     * @return the tinss3
     */
    public Double getTinss3() {
        return tinss3;
    }

    /**
     * @param tinss3 the tinss3 to set
     */
    public void setTinss3(Double tinss3) {
        this.tinss3 = tinss3;
    }

    /**
     * @return the ainss3
     */
    public Double getAinss3() {
        return ainss3;
    }

    /**
     * @param ainss3 the ainss3 to set
     */
    public void setAinss3(Double ainss3) {
        this.ainss3 = ainss3;
    }

    /**
     * @return the tinss4
     */
    public Double getTinss4() {
        return tinss4;
    }

    /**
     * @param tinss4 the tinss4 to set
     */
    public void setTinss4(Double tinss4) {
        this.tinss4 = tinss4;
    }

    /**
     * @return the ainss4
     */
    public Double getAinss4() {
        return ainss4;
    }

    /**
     * @param ainss4 the ainss4 to set
     */
    public void setAinss4(Double ainss4) {
        this.ainss4 = ainss4;
    }

    /**
     * @return the tsf
     */
    public Double getTsf() {
        return tsf;
    }

    /**
     * @param tsf the tsf to set
     */
    public void setTsf(Double tsf) {
        this.tsf = tsf;
    }

    /**
     * @return the vsf
     */
    public Double getVsf() {
        return vsf;
    }

    /**
     * @param vsf the vsf to set
     */
    public void setVsf(Double vsf) {
        this.vsf = vsf;
    }

    /**
     * @return the tirrf1
     */
    public Double getTirrf1() {
        return tirrf1;
    }

    /**
     * @param tirrf1 the tirrf1 to set
     */
    public void setTirrf1(Double tirrf1) {
        this.tirrf1 = tirrf1;
    }

    /**
     * @return the tirrf2
     */
    public Double getTirrf2() {
        return tirrf2;
    }

    /**
     * @param tirrf2 the tirrf2 to set
     */
    public void setTirrf2(Double tirrf2) {
        this.tirrf2 = tirrf2;
    }

    /**
     * @return the tirrf3
     */
    public Double getTirrf3() {
        return tirrf3;
    }

    /**
     * @param tirrf3 the tirrf3 to set
     */
    public void setTirrf3(Double tirrf3) {
        this.tirrf3 = tirrf3;
    }

    /**
     * @return the tirrf4
     */
    public Double getTirrf4() {
        return tirrf4;
    }

    /**
     * @param tirrf4 the tirrf4 to set
     */
    public void setTirrf4(Double tirrf4) {
        this.tirrf4 = tirrf4;
    }

    /**
     * @return the tirrf5
     */
    public Double getTirrf5() {
        return tirrf5;
    }

    /**
     * @param tirrf5 the tirrf5 to set
     */
    public void setTirrf5(Double tirrf5) {
        this.tirrf5 = tirrf5;
    }

    /**
     * @return the airrf1
     */
    public Double getAirrf1() {
        return airrf1;
    }

    /**
     * @param airrf1 the airrf1 to set
     */
    public void setAirrf1(Double airrf1) {
        this.airrf1 = airrf1;
    }

    /**
     * @return the airrf2
     */
    public Double getAirrf2() {
        return airrf2;
    }

    /**
     * @param airrf2 the airrf2 to set
     */
    public void setAirrf2(Double airrf2) {
        this.airrf2 = airrf2;
    }

    /**
     * @return the airrf3
     */
    public Double getAirrf3() {
        return airrf3;
    }

    /**
     * @param airrf3 the airrf3 to set
     */
    public void setAirrf3(Double airrf3) {
        this.airrf3 = airrf3;
    }

    /**
     * @return the airrf4
     */
    public Double getAirrf4() {
        return airrf4;
    }

    /**
     * @param airrf4 the airrf4 to set
     */
    public void setAirrf4(Double airrf4) {
        this.airrf4 = airrf4;
    }

    /**
     * @return the airrf5
     */
    public Double getAirrf5() {
        return airrf5;
    }

    /**
     * @param airrf5 the airrf5 to set
     */
    public void setAirrf5(Double airrf5) {
        this.airrf5 = airrf5;
    }

    /**
     * @return the dirrf2
     */
    public Double getDirrf2() {
        return dirrf2;
    }

    /**
     * @param dirrf2 the dirrf2 to set
     */
    public void setDirrf2(Double dirrf2) {
        this.dirrf2 = dirrf2;
    }

    /**
     * @return the dirrf3
     */
    public Double getDirrf3() {
        return dirrf3;
    }

    /**
     * @param dirrf3 the dirrf3 to set
     */
    public void setDirrf3(Double dirrf3) {
        this.dirrf3 = dirrf3;
    }

    /**
     * @return the dirrf4
     */
    public Double getDirrf4() {
        return dirrf4;
    }

    /**
     * @param dirrf4 the dirrf4 to set
     */
    public void setDirrf4(Double dirrf4) {
        this.dirrf4 = dirrf4;
    }

    /**
     * @return the dirrf5
     */
    public Double getDirrf5() {
        return dirrf5;
    }

    /**
     * @param dirrf5 the dirrf5 to set
     */
    public void setDirrf5(Double dirrf5) {
        this.dirrf5 = dirrf5;
    }

    /**
     * @return the dedpdep
     */
    public Double getDedpdep() {
        return dedpdep;
    }

    /**
     * @param dedpdep the dedpdep to set
     */
    public void setDedpdep(Double dedpdep) {
        this.dedpdep = dedpdep;
    }
    
}