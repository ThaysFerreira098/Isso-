package com.folha.folha.service;
import com.folha.folha.model.Funcionario;
import com.folha.folha.model.Tabelas;
import com.folha.folha.repository.FunRepository;
import com.folha.folha.repository.TabRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FolhaService {
    @Autowired
private FunRepository fr;
    @Autowired
private TabRepository tr;

public void salvar(Funcionario funcionario){
        fr.save(funcionario);
}
    public Optional<Funcionario> buscarPorId(Integer id) {
        return fr.findById(id);
    }

public List<Funcionario> listar(){
        return fr.findAll();
    }
 public List<Funcionario> listafuncionario(){
     return fr.findAll();
 }
 

  public Tabelas buscarTabelas() { //listar tabelas 
        List<Tabelas> lista = tr.findAll();
        if (lista.isEmpty()) {
            return new Tabelas();
        } else {
            return lista.get(0); 
        }
    }
  
public void salvarTab(Tabelas tabelas) { //salvar tabelas
    //obs:Não se colocar Salvar/localizar tabelas 
    List<Tabelas> lista =tr.findAll();
    
    if (!lista.isEmpty()) {
        Tabelas existente = lista.get(0);
        tabelas.setId(existente.getId()); 
    }
        tr.save(tabelas);
}
}
