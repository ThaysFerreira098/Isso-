package com.folha.folha.service;
import com.folha.folha.model.Funcionario;
import com.folha.folha.model.Tabelas;
import com.folha.folha.repository.FunRepository;
import com.folha.folha.repository.TabRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FolhaService {
    @Autowired
private FunRepository fr;
    @Autowired
private TabRepository tr;

public void salvar(Funcionario funcionario){
        fr.save(funcionario);
}
public List<Funcionario> listar(){
        return fr.findAll();
    }
public List<Tabelas> listarTab(){
    return tr.findAll();
}
public void edita (){
    
}
}
