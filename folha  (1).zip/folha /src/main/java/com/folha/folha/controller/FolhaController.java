package com.folha.folha.controller;
import com.folha.folha.service.FolhaService;
import com.folha.folha.model.Funcionario;
import com.folha.folha.model.Tabelas;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;



@Controller
@RequestMapping("/folha")
public class FolhaController {
    
    @Autowired
    FolhaService fs;
    
    @Autowired
    FolhaService tr;


    @GetMapping("/")
    public String cadastros(Model model){
        Funcionario funcionario = new Funcionario();
        model.addAttribute("funcionario", funcionario);
        
        return "paginas/form-funcionario";
    }
        @GetMapping("/lista")
     public String listarfuncionario(Model model){
        Funcionario listafuncionario = new Funcionario();
        model.addAttribute("listafuncionario", listafuncionario);
     return "paginas/lista";
 }
    @PostMapping("/salvar")
public String salvar(@ModelAttribute("funcionario") Funcionario funcionario){
         fs.salvar(funcionario);
         return "redirect:/folha/";
}
    
    @GetMapping("/tabelas")
    public String cadastroimposto(Model model) {
        Tabelas tabelas = tr.buscarTabelas(); //metodo listar a tabela
        
        model.addAttribute("tabelas", tabelas);
        
        return "paginas/tela"; 
    }

@PostMapping("/salvarTab")
public String salvarTab(@ModelAttribute("tabelas") Tabelas tabelas) {
    tr.salvarTab(tabelas); 
        return "redirect:/folha/tabelas";
}
@GetMapping("/Edita")
    public String edita(@RequestParam("id") Integer id, Model model) {
        Optional<Funcionario> funcionarioOpt = fs.buscarPorId(id);
        if (funcionarioOpt.isPresent()) {
            model.addAttribute("funcionario", funcionarioOpt.get());
            return "paginas/lista"; // a tela que edita/cadastra funcionario
        }
        return "redirect:/folha/"; // se não achou, volta pra lista/tela inicial
    }
}
 



