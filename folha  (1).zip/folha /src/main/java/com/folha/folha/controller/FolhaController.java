package com.folha.folha.controller;
import com.folha.folha.service.FolhaService;
import com.folha.folha.model.Funcionario;
import com.folha.folha.model.Tabelas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/folha")
public class FolhaController {
    
    @Autowired
    FolhaService fs;

    @GetMapping("/")
    public String cadastros(Model model){
        Funcionario funcionario = new Funcionario();
        model.addAttribute("funcionario", funcionario);
        
        return "paginas/form-funcionario";
    }
    
    @GetMapping("/tabelas")
     public String cadastro(Model model){
                 Tabelas tabelas = new Tabelas();
        model.addAttribute("tabelas", tabelas);
        
        return "paginas/form-tabela";
        }
     
@PostMapping("/salvar")
public String salvar(@ModelAttribute("funcionario") Funcionario funcionario){
         fs.salvar(funcionario);
         return "redirect:/folha/";
}
//@GetMapping("/edita")
 //public String editatabela(@RequestParam("id") Integer id, Model model){
   // Optional<Cardapio> cardapio=cr.findById(id);
 //if(cardapio.isPresent()) {
 //model.addAttribute("cardapio", cardapio.get());
 //return "paginas/form-cardapio";
 //}
 //return "/cardapio/";
 //}
}
//coloocar editar na tabela 
