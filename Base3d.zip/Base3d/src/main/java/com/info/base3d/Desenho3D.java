
package com.info.base3d;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class Desenho3D {
 double xwmax, xwmin, ywmax, ywmin, zwmax, zwmin, xvmax, xvmin, yvmax, yvmin, zvmax, zvmin;
    private double xmax,ymax,xcoord,ycoord,zcoord,xd,yd;
    private double centrox;
    private double centroy;
    List<Ponto> desenho = new ArrayList<>();
    public void setMundo(double x1,double y1,double x2,double y2,double z2,double z1){
    xwmax = x2;
    ywmax = y2;
    zwmax=  z2;
    xwmin = x1;
    ywmin = y1;
    zwmin = z1;
    centrox = (x1 + x2) / 2;
    centroy = (y1 + y2) / 2;
}
     public void setDimension(Dimension d){
        xmax = d.width;
        ymax =d.height;
    }
      public void setViewPort(double x1,double y1,double x2,double y2){
        xvmax = x2;
        yvmax = y2;
        xvmin =x1;
        yvmin =y1;
    }
      private void mapCoord(double x,double y,double z){
          double zv;
          if(z<0) {
              zv= 1/(1+Math.abs(z)/(zwmax-zwmin));
              } else {
                zv = (1 + Math.abs(z) / (zwmax - zwmin));
                    }
          x = x / zv;
          y = y / zv;
         double xv = (((x - xwmin) * ((xvmax - xvmin) / (xwmax - xwmin))) + xvmin);
         double yv = (((y - ywmin) * ((yvmax - yvmin) / (ywmax - ywmin))) + yvmin);
         xd = xv * xmax;
         yd = yv * ymax;
          }
       private void linhaAte(Graphics g, double x, double y, double z) {
        double xi, yi;
        mapCoord(xcoord, ycoord, zcoord);
        xi = xd;
        yi = yd;
        mapCoord(x, y, z);
        g.drawLine((int) xi, (int) yi, (int) xd, (int) yd);
        xcoord = x;
        ycoord = y;
        zcoord = z;
 } 
        private void movaPara(Graphics g, double x, double y, double z, boolean pu) {
        if (pu) {
        xcoord = x;
        ycoord = y;
        zcoord = z;
        } else {
        linhaAte(g, x, y, z);
        }
 } 
         public void desenha(Graphics g) {
        for (Ponto p : desenho) {
        movaPara(g, p.getX(), p.getY(), p.getZ(), p.isPu());
        }
 }
    public void cubo() {
     desenho.add(new Ponto(11, 10, 1, true));
     desenho.add(new Ponto(11, 11, 1, false));
     desenho.add(new Ponto(12, 11, 1, false));
     desenho.add(new Ponto(12, 10, 1, false));
     desenho.add(new Ponto(11, 10, 1, false));
     desenho.add(new Ponto(11, 10, 2, false));
     desenho.add(new Ponto(11, 11, 2, false));
     desenho.add(new Ponto(12, 11, 2, false));
     desenho.add(new Ponto(12, 10, 2, false));
     desenho.add(new Ponto(11, 10, 2, false));
     desenho.add(new Ponto(11, 11, 2, false));
     desenho.add(new Ponto(11, 11, 1, false));
     desenho.add(new Ponto(12, 11, 1, false));
     desenho.add(new Ponto(12, 11, 2, false));
     desenho.add(new Ponto(12, 10, 2, false));
     desenho.add(new Ponto(12, 10, 1, false));
     }
    public void translada(double dx, double dy, double dz) {
    for (Ponto p : desenho) {
    p.setX(p.getX() + dx);
    p.setY(p.getY() + dy);
    p.setZ(p.getZ() + dz);
    }
 } 
     public void rotaciona(double h, double q, double b) {
        double m[][] = new double[4][4];
        double ch = Math.cos(h);
        double cp = Math.cos(q);
        double cb = Math.cos(b);
        double sh = Math.sin(h);
        double sp = Math.sin(q);
        double sb = Math.sin(b);
        m[1][1] = ch * cb - sh * sp * sb;
        m[1][2] = sb * ch + cb * sp * sh;
        m[1][3] = -cp * sh;
        m[2][1] = -sb * cp;
        m[2][2] = cb * cp;
        m[2][3] = sp;
        m[3][1] = cb * sh + sb * sp * ch;
        m[3][2] = sb * sh - cb * sp * ch;
        m[3][3] = ch * cp;
        for (Ponto p : desenho) {
        double x = p.getX();
        double y = p.getY();
        double z = p.getZ(); 
        double xx = (x * m[1][1] + y * m[1][2] + z * m[1][3]);
        double yy = (x * m[2][1] + y * m[2][2] + z * m[2][3]);
        double zz = (x * m[3][1] + y * m[3][2] + z * m[3][3]);
        p.setX(xx);
        p.setY(yy);
        p.setZ(zz);
    }
 } 
            public void deforma(boolean maior) {
       for (Ponto p : desenho) {
       if (maior) {
       p.setX(((p.getX() - getCentrox()) * 0.1) + p.getX());
       p.setY(((p.getY() - getCentroy()) * 0.1) + p.getY());
       p.setZ((p.getZ() * 0.1) + p.getZ());
       } else {
       p.setX(p.getX() - ((p.getX() - getCentrox()) * 0.1));
       p.setY(p.getY() - ((p.getY() - getCentroy()) * 0.1));
       p.setZ(p.getZ() - (p.getZ() * 0.1));
       }
    }
 }
    public double getCentroy() {
    return centroy;
    }
    public void setCentroy(double centroy) {
    this.centroy = centroy;
    }
    public double getCentrox() {
    return centrox;
    }
    public void setCentrox(double centrox) {
    this.centrox = centrox;
 }
}


