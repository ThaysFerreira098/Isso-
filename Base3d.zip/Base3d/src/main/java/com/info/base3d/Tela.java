
package com.info.base3d;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;

    public class Tela extends JFrame {
    public Tela () {
        setBackground(Color.BLACK);
        setForeground(Color.white);
        setUndecorated(true);
        Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
        Dimension scrSize = toolkit.getScreenSize();
        setSize(scrSize.width,scrSize.height);
        add(new Painel(scrSize.width,scrSize.height,this));
        setResizable (false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args){
        new Tela();
    }
    
}

