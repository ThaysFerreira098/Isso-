
package Info.com;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
public class Desenho {

    private double xwmax, xwmin,ywmax,ywmin,xvmax,xvmin,yvmax,yvmin;
    private double xmax,ymax,xcoord,ycoord,xd,yd,mx,my;
    List<Ponto> desenho = new ArrayList<>();
    public void setMundo(double x1,double y1,double x2,double y2){
        xwmax = x2;
        ywmax = y2;
        xwmin = x1;
        ywmin = y1;
}
    public void setDimension(Dimension d){
        xmax = d.width;
        ymax =d.height;
    }
    public double getMouseX(){
        return mx;
}
    public double getMouseY(){
        return my;
    }
    public void setMouse(int x, int y){
        mx=(((x-xvmin) / ((xvmax - xvmin) / (xwmax - xwmin))) + xwmin)/ xmax;
        my=(((y-yvmin) / ((yvmax - xvmin) / (ywmax - ywmin))) + ywmin)/ ymax;

    }
    public void setViewPort(double x1,double y1,double x2,double y2){
        xvmax = x2;
        yvmax = y2;
        xvmin =x1;
        yvmin =y1;
    }

private void mapCoord(double x, double y) {
double xv =(((x-xwmin) * ((xvmax -xvmin) / (xwmax -xwmin))) + xvmin);
double yv =(((y-ywmin) * ((yvmax -yvmin) / (ywmax -ywmin))) + yvmin);
xd = xv * xmax;
yd =yv * ymax;

}
private void linhaAte(Graphics g, double x,double y) {
   double xi,yi;
   mapCoord(xcoord,ycoord);
   xi = xd;
   yi =yd;
   mapCoord(x,y);
   g.drawLine((int) xi,(int) yi,(int) xd,(int)yd);
   xcoord = x;
   ycoord = y;
}
private void movaPara(Graphics g,double x,double y,boolean pu){
    if(pu) {
        xcoord = x;
        ycoord = y;
    }else{
        linhaAte(g,x,y);
    }
}
public void desenha(Graphics g){
    Ponto p;
    for(int i = 0;i <desenho.size();i++){
        p =(Ponto) desenho.get(i);
        movaPara(g,p.getX(),p.getY(),p.isPu());
    }
}
 public void triangulo() {
    
    // 🔷 Monitor (vai ficar em cima agora)
    desenho.add(new Ponto(8d, 0d, true));   // 12 -> 0
    desenho.add(new Ponto(16d, 0d, false));
    desenho.add(new Ponto(16d, 4d, false)); // 8 -> 4
    desenho.add(new Ponto(8d, 4d, false));
    desenho.add(new Ponto(8d, 0d, false));

    // 🔷 Base do monitor
    desenho.add(new Ponto(11d, 4d, true));  // 8 -> 4
    desenho.add(new Ponto(13d, 4d, false));
    desenho.add(new Ponto(12d, 5d, false)); // 7 -> 5
    desenho.add(new Ponto(11d, 4d, false));

    // 🔷 Pé
    desenho.add(new Ponto(10d, 5d, true));  // 7 -> 5
    desenho.add(new Ponto(14d, 5d, false));
    desenho.add(new Ponto(12d, 6d, false)); // 6 -> 6
    desenho.add(new Ponto(10d, 5d, false));

    // 🔷 Teclado (agora embaixo)
    desenho.add(new Ponto(9d, 7d, true));   // 5 -> 7
    desenho.add(new Ponto(15d, 7d, false));
    desenho.add(new Ponto(15d, 8d, false)); // 4 -> 8
    desenho.add(new Ponto(9d, 8d, false));
    desenho.add(new Ponto(9d, 7d, false));

    // 🔷 Mouse
    desenho.add(new Ponto(16d, 7d, true));
    desenho.add(new Ponto(17d, 7d, false));
    desenho.add(new Ponto(17d, 8d, false));
    desenho.add(new Ponto(16d, 8d, false));
    desenho.add(new Ponto(16d, 7d, false));

    // 🔷 CPU (lado)
    desenho.add(new Ponto(18d, 1d, true));  // 11 -> 1
    desenho.add(new Ponto(20d, 1d, false));
    desenho.add(new Ponto(20d, 5d, false)); // 7 -> 5
    desenho.add(new Ponto(18d, 5d, false));
    desenho.add(new Ponto(18d, 1d, false));
}
public void translada (double dx,double dy){
    Ponto p;
    for(int i = 0;i <desenho.size();i++){
        p =(Ponto) desenho.get(i);
        p.setX(p.getX() +dx);
        p.setY(p.getY()+dy);
        desenho.set(i,p);
    }
}
  public void rotaciona (double ang) {
      Ponto p;
      for(int i = 0; i<desenho.size();i++){
        p = (Ponto) desenho.get(i);
        double xx = p.getX();
        double yy =p.getY();
        p.setX(xx * Math.cos(ang) + yy *(-Math.sin(ang)));
        p.setY(xx * Math.sin(ang) + yy *Math.cos(ang));
        desenho.set(i,p);
      }
  }
  public void deforma (boolean maior) {
      Ponto p;
      for (int i = 0; i < desenho.size();i++) {
          if(maior) {
              p =(Ponto) desenho.get(i);
              p.setX (((p.getX()-mx) * 0.1) + p.getX());
              p.setY (((p.getX()-mx) * 0.1) + p.getY());
              desenho.set(i,p);
          } else {
            p =(Ponto) desenho.get(i);
            p.setX(p.getX()-((p.getX() - mx) * 0.1));
            p.setY(p.getY() - ((p.getY()- my)*0.1));
            desenho.set(i,p);
          }
      }
  }
}
